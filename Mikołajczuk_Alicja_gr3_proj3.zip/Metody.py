# -*- coding: utf-8 -*-
"""
Created on Sun Jun  9 12:28:19 2019

@author: Alicja
"""
import datetime as dt
from math import sqrt, atan, cos, sin, pi, tan, fabs

#sprawdzenie wartosci
def check_values(self, element): 
        
    if element .text().lstrip('-').replace('.','',1).isdigit():
        return float(element.text())
    else:
        element.setFocus()
        return None
    
#algorytm vincentego   
def vincent(fi, la, fib, lab, a = 6378137.0, e2 = 0.00669438):
    fi = fi*pi/180
    la = la*pi/180
    fib = fib*pi/180
    lab = lab*pi/180
    b = a*sqrt(1-e2)
    f = 1 - (b/a)
    L = lab - la

    Ua = atan((1-f)*tan(fi))
    Ub = atan((1-f)*tan(fib))

    while True:
        ss=sqrt((cos(Ub)*sin(L))**2 + (cos(Ua)*sin(Ub) - sin(Ua)*cos(Ub)*cos(L))**2)
#        
        cs=sin(Ua)*sin(Ub)+cos(Ua)*cos(Ub)*cos(L);
#       
        sig=atan(ss/cs);
#        
        sa=(cos(Ua)*cos(Ub)*sin(L))/sin(sig)
#       
        ca2=1-(sa)**2
        c2s=cs-(2*sin(Ua)*sin(Ub))/ca2
        C=(f/16)*ca2*(4+f*(4-3*ca2))
        Ls=L;
        L=lab-la+(1-C)*f*sa*(sig+C*ss*(c2s+C*cs*(-1+2*(c2s)**2)));
        if fabs(L-Ls) < (0.000001/206265):
            break
    u2=((a**2-b**2)/b**2)*ca2
    A=1+(u2/16384)*(4096+u2*(-768+u2*(320-175*u2)))
    B=(u2/1024)*(256+u2*(-128+u2*(74-47*u2)))
    ds=B*ss*(c2s+(1/4)*B*(cs*(-1+2*(c2s)**2)-(1/6)*B*c2s*(-3+4*(ss)**2)*(-3+4*(c2s)**2)))
    S=b*A*(sig-ds)
    
    return S


# obliczenie odleglosci uwzgledniajac ksztalt terenu
def S(lat, lon, el):
    k = len(lat)
    if len(lat) == len  (lon) == len(el):
        i = 0
        S = []
        while i < (k -1):
            fi = lat[i]
            la = lon[i]
            fib = lat[i+1]
            lab = lon[i+1]
            el1 = el[i]
            el2 = el[i+1]
            if fib == 0 or lab == 0 or fi == 0 or la == 0:
                d = 0
                S.append(d)
                pass
            elif fib == fi and lab == la: 
                
                d = 0
                S.append(d)
                pass
            else:
                d2D = vincent(fi, la, fib, lab, a = 6378137.000, e2 = 0.00669438)
                S3D = sqrt(d2D**2 + (el2 - el1)**2)
                S.append(S3D)
            
                
            i += 1
    else: 
        S3D = 'Brak'
        pass        
    return S

#przewyzszenia
def dh(el):
    k = len(el)

    i = 0
    dh = []
    while i < (k -1):
        el1 = el[i]
        el2 = el[i+1]
        if el1 == 0 and el2 == 0:
            d = 0
            dh.append(d)
            pass
        elif el1 == el2: 
            d = 0
            dh.append(d)
            pass
        else:

            dh1 = el2 - el1
            dh.append(dh1)
        i += 1

    return dh

#wysokosci
def H(el,dh): 
    Hp = el[0]
    H = []
    for dH in dh:
        Hp = Hp + dH
        H.append(Hp)
        
    return H


def zejscia_podejscia(dh):
    k = len(dh)
    i = 0 
    podejscia = []
    zejscia = []
    while i < (k -1):
        d_el = dh[i]
        if d_el > 0:
            podejscia.append(d_el)
        elif d_el < 0:
            zejscia.append(d_el)
        i += 1
     
    suma_podejsc = sum(podejscia)
    suma_zejsc = sum(zejscia)
    
    return [suma_podejsc, suma_zejsc]

#calkowity czas trasy
def cal_czas(dates):
    cal_czas = dates[-1]-dates[1]
    return cal_czas

#srednia predkosc
def V(cal_czas, S):
    a = str(cal_czas).split(':')
    h = float(a[0])
    m = (float(a[1]))/60
    s = (float(a[2]))/3600
    V = (sum(S)/1000)/(h+m+s)
    return V



