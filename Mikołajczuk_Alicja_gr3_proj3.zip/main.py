# -*- coding: utf-8 -*-
"""
Created on Tue May 14 10:39:45 2019

@author: Alicja
"""
from kivy.garden.mapview import MapView
from kivy.app import App
from kivy.uix.boxlayout import BoxLayout
from kivy.properties import ObjectProperty
from kivy.garden.mapview import MapMarker, MarkerMapLayer
import gpx 



import matplotlib.pyplot as plt
import Metody
import numpy as np


 
    
class AddLocationForm(BoxLayout):
    
    my_map = ObjectProperty()  
    txt = ObjectProperty()
            
    def analyse_file(self):

        #wczytanie pliku
        filename = 'wokol_wisly.gpx'# wskazanie sciezki do pliku
        
        
        lat, lon, el, dates = gpx.wczytaj_plik(filename)
        #obliczenie statystyk
        S = Metody.S(lat, lon, el)
        self.txt.text = "-Całkowita długosc trasy [m]: "
        self.txt.text += str(sum(S))
        
        dh = Metody.dh(el)
        self.txt.text += "\n-Suma przewyzszen [m]: "
        self.txt.text += str(sum(dh))   
        
        H = Metody.H(el,dh)
        self.txt.text +="\n-Maksymalna wysokosc [m]: "
        self.txt.text += str(max(H))
        
        self.txt.text +="\n-Minimalna wysokosc [m]: "
        self.txt.text += str(min(H))
        
        podejscia_zejscia = Metody.zejscia_podejscia(dh) 
        self.txt.text += "\n-Suma podejsc [m]: "
        self.txt.text += str(podejscia_zejscia[0]) 
        self.txt.text += "\n-Suma zejsc [m]: "
        self.txt.text += str(podejscia_zejscia[1]) 
        
        cal_czas = Metody.cal_czas(dates)
        self.txt.text += "\n-Czas trwania [h:min:sec]: "
        self.txt.text +=  str(cal_czas)
        
        V = Metody.V(cal_czas, S)
        self.txt.text += "\n-Srednia predkosc [km/h]: "
        self.txt.text += str(V)
        
        #narysuj sciezke
        self.draw_route(lat[::10],lon[::10])
        
        
        
        
        
    def draw_route(self, lon, lat):
        data_layer = MarkerMapLayer()
        self.my_map.add_layer(data_layer)
        
        for point in zip (lat, lon):
            self.mark_point(*point, layer = data_layer)
         
    
    
    
    def mark_point(self, lat, lon, layer=None, markerSource='dot.png'):
        if lat!=None and lon!=None:
            marker = MapMarker(lat=lat, lon=lon, source=markerSource)
            self.my_map.add_marker(marker, layer = layer)
        
        

        
        
    

class MapViewApp(App):
    def build(self):
        return AddLocationForm()

if __name__ == '__main__':
    MapViewApp().run()
