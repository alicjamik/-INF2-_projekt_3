# -*- coding: utf-8 -*-
"""
Created on Tue May 28 11:07:28 2019

@author: Alicja
"""
import gpxpy as gpx
import datetime as dt

filename = 'krk1.gpx'
def wczytaj_plik(filename):
    lat =[]
    lon =[]
    el =[]
    dates =[]
    
    
    with open(filename, 'r' ) as gpx_file:
        gpx_dane = gpx.parse(gpx_file) 
    
    print(gpx_dane.tracks[0].segments[0].points[0])
    
    for track in gpx_dane.tracks:
        for seg in track.segments:
            for point in seg.points:
                lon.append(point.longitude)
                lat.append(point.latitude)
                
                if point.elevation is None:
                    pass
                else:
                    el.append(point.elevation)
                
                if point.time is None:
                    pass
                else:
                    point.time = point.time.replace(tzinfo=None)
                    dates.append(point.time)
                    
    return lon, lat, el, dates

    